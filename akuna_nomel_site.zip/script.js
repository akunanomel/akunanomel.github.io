
document.getElementById('year').textContent = new Date().getFullYear();
const form = document.getElementById('contact-form');
const status = document.getElementById('form-status');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  status.textContent = 'Sending…';
  const data = new FormData(form);
  try {status.textContent = 'Message sent!'; form.reset();} 
  catch(err){status.textContent='Error sending message.';}
});
